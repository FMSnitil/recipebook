
export const recipeList = {
  "recipeLists":[
    {
      "name": "Česká kuchyně",
      "recipes" :[  {
        name: "Čínské nudle",
        ingredients: ["kuřecí maso", "kokosové mléko", "zelenina", "kari koření", "rýže"],
        preparationProcess: "1. Osmažte hovězí maso s nakrájenou zeleninou v hrnci. 2. Přidejte kari koření a restujte krátce. 3. Přilijte kokosové mléko a nechte vařit do změknutí masa. 4. Servírujte s uvařenou rýží."
      },
      {
        name: "Cézar salát",
        ingredients: ["kuřecí prsa", "ledový salát", "parmezán", "krutony", "Cézar dresink"],
        preparationProcess: "1. Na pánvi osmažíme na kostičky nakrájené kuřecí prsa. 2. Připravíme si ledový salát, na který nandáme osmažené kuřecí maso. 3. Posypeme parmezánem a krutony. 4. Dochutíme Cézar dresinkem."
      }
    
    ]
    },
    {
      "name": "Italská kuchyně",
      "recipes" :[  {
        name: "Čínské nudle",
        ingredients: ["kuřecí maso", "kokosové mléko", "zelenina", "kari koření", "rýže"],
        preparationProcess: "1. Osmažte hovězí maso s nakrájenou zeleninou v hrnci. 2. Přidejte kari koření a restujte krátce. 3. Přilijte kokosové mléko a nechte vařit do změknutí masa. 4. Servírujte s uvařenou rýží."
      }

    ]
      
    },
  ]
}



    
    
    
  
