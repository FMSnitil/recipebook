import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes, Link, useParams } from 'react-router-dom';
import { recipeList } from './data';
import './App.css'; // Importuje soubor app.css

function RecipeListPage() {
  const { listIndex } = useParams();
  const [recipeLists, setRecipeLists] = useState(recipeList.recipeLists);

  const addRecipeToSpecificList = (listIndex, recipe) => {
    const updatedLists = [...recipeLists];
    updatedLists[listIndex].recipes.push(recipe);
    setRecipeLists(updatedLists);
  };

  const removeRecipeFromList = (listIndex, recipeIndex) => {
    const updatedLists = [...recipeLists];
    updatedLists[listIndex].recipes.splice(recipeIndex, 1);
    setRecipeLists(updatedLists);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const name = e.target.elements.name.value;
    const ingredients = e.target.elements.ingredients.value.split(',');
    const preparationProcess = e.target.elements.preparationProcess.value;
    const newRecipe = { name, ingredients, preparationProcess };
    addRecipeToSpecificList(listIndex, newRecipe);
    e.target.reset();
  };

  const list = recipeLists[listIndex];

  if (!list) {
    return <div>Seznam receptů je prázdný</div>;
  }

  return (
    <div className=''>
      <h2>{list.name}</h2>
      <ul className='lists'>
        {list.recipes.map((recipe, recipeIndex) => (
          <li  className='lists-item' key={recipeIndex}>
            <h3>{recipe.name}</h3>
            <p>Ingredients: {recipe.ingredients.join(', ')}</p>
            <p>Preparation Process: {recipe.preparationProcess}</p>
            <button onClick={() => removeRecipeFromList(listIndex, recipeIndex)}>Smazat recept</button>
          </li>
        ))}
      </ul>
      <h3>Přidat nový recept</h3>
      <form className='form-add' onSubmit={handleSubmit}>
        <input type="text" name="name" placeholder="Název receptu" required />
        <br/>
        <input type="text" name="ingredients" placeholder="Ingredience (oddělené čárkou)" required />
        <br/>
        <textarea name="preparationProcess" placeholder="Postup přípravy" required></textarea>
        <br/>
        <button className='btn' type="submit">Přidat recept</button>
      </form>
    </div>
  );
}


function RecipeDetailPage({ match }) {
  const listIndex = parseInt(match.params.listIndex, 10);
  const recipeIndex = parseInt(match.params.recipeIndex, 10);
  const list = recipeList.recipeLists[listIndex];
  const recipe = list.recipes[recipeIndex];

  return (
    <div>
      <h2>{recipe.name}</h2>
      <p>Ingredience: {recipe.ingredients.join(', ')}</p>
      <p>Příprava Process: {recipe.preparationProcess}</p>
    </div>
  );
}

function App() {
  const [recipeLists, setRecipeLists] = useState(recipeList.recipeLists);

  const addRecipeList = (name) => {
    const newList = [...recipeLists, { name, recipes: [] }];
    setRecipeLists(newList);
  };

  return (
    <Router>
      <div>
        <h1>Seznamy receptů</h1>
        <Routes>
          <Route exact path="/" element={
            <div>
              <ul>
                {recipeLists.map((list, index) => (
                  <li key={index}>
                    <Link to={`/list/${index}`}>{list.name}</Link>
                  </li>
                ))}
              </ul>
              <form onSubmit={(e) => {
                e.preventDefault();
                const name = e.target.elements.name.value;
                addRecipeList(name);
                e.target.reset();
              }}>
                <input type="text" name="name" placeholder="Asijská kuchyně"  required/>
                <button type="submit">Vytvořit</button>
              </form>
            </div>
          } />
          <Route path="/list/:listIndex" element={<RecipeListPage />} />
          <Route path="/list/:listIndex/recipe/:recipeIndex" element={<RecipeDetailPage />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
